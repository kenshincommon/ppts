package com.kenshin.cache.test1;

import java.util.concurrent.TimeUnit;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;


public class TestCache1 {

	public static void main(String[] args) {
		DefaultCacheManager manager = new DefaultCacheManager();
		Cache<Object, Object> cache = manager.getCache();
		TestCacheListener listener = new TestCacheListener();
		manager.addListener(listener);
		cache.addListener(listener);
		cache.put("key1", "value1");
		cache.put("key2", "value2",3,TimeUnit.SECONDS);
		cache.put("key3", "value3",5,TimeUnit.SECONDS);
		
		System.out.println("Keys 1: "+cache.keySet());
		sleep(3500);
		System.out.println("Keys 2: "+cache.keySet());
		sleep(2000);
		System.out.println("Keys 3: "+cache.keySet());
		
		cache.evict("key1");
		System.out.println("Keys 4: "+cache.keySet());
		
		cache.stop();
	}
	
	private static void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
