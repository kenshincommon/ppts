package com.kenshin.cache.test1;

import org.infinispan.notifications.Listener;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryCreated;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryRemoved;
import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.infinispan.notifications.cachemanagerlistener.annotation.CacheStarted;
import org.infinispan.notifications.cachemanagerlistener.annotation.CacheStopped;
import org.infinispan.notifications.cachemanagerlistener.event.CacheStartedEvent;
import org.infinispan.notifications.cachemanagerlistener.event.CacheStoppedEvent;

@Listener(sync=false)
public class TestCacheListener {

	@CacheEntryCreated
	public void addEntry(CacheEntryCreatedEvent<Object, Object> evt) {
		if (evt.isPre()) {
			System.out.println("Going to add: " + evt.getKey());
		} else {
			System.out.println("Added: " + evt.getKey());
		}
	}

	@CacheEntryRemoved
	public void removeEntry(CacheEntryRemovedEvent<Object, Object> evt) {
		if (evt.isPre()) {
			System.out.println("Going to remove: " + evt.getKey());
		} else {
			System.out.println("Removed entry " + evt.getKey());
		}
	}

	@CacheStarted
	public void cacheStarted(CacheStartedEvent event) {
		System.out.println("Cache Started");
	}

	@CacheStopped
	public void cacheStopped(CacheStoppedEvent event) {
		System.out.println("Cache Stopped");
	}

}
