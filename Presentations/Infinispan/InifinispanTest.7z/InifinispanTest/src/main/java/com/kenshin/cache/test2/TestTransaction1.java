package com.kenshin.cache.test2;

import javax.transaction.TransactionManager;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;

public class TestTransaction1 {

	public static final String CONFIG_NAME = "config4-tx.xml";
	
	public static void main(String[] args) throws Exception {
		DefaultCacheManager manager = new DefaultCacheManager(CONFIG_NAME);
		Cache<Object, Object> cache = manager.getCache("tx_cache");
		
		TransactionManager tx = cache.getAdvancedCache().getTransactionManager();
		System.out.println("Tx obtained: " + tx);
		
		//commit
		tx.begin();
		cache.put("key1", "value1");
		tx.commit();
		
		//rollback
		tx.begin();
		cache.put("key2", "value2");
		cache.put("key3", "value3");
		tx.rollback();
		
		System.out.println("Keys: " + cache.keySet());
		
		cache.stop();
	}
	
}
