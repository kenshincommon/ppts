package com.kenshin.cache.test3;

import java.io.IOException;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;

public class TestCacheConfig1 {

	//LRU maxEntries = 3
	private static final String CONFIG_NAME = "config1-LRU-3max.xml";
	
	private static void testCache(Cache<Object, Object> cache) throws IOException {
		cache.put("key1", "value1");
		cache.put("key2", "value2");
		cache.put("key3", "value3");
		
		System.out.println(cache.get("key2"));
		
		cache.put("key4", "value4");
		cache.put("key5", "value5");
		
		System.out.println("Keys: "+cache.keySet());
		
		cache.stop();
	}
	
	public static void main(String[] args) throws IOException {
		DefaultCacheManager manager = new DefaultCacheManager(CONFIG_NAME);
		Cache<Object, Object> cache = manager.getCache();
		testCache(cache);
		
		Cache<Object, Object> namedCache = manager.getCache("cache1");
		testCache(namedCache);
	}
	
}
