package com.kenshin.cache.test4;

import java.io.IOException;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;

public class TestCacheLoader {

	private static final String CONFIG_NAME = "config2-cache-Loader.xml";
	
	public static void addEntries(Cache<Object, Object> cache) throws IOException {
		addEntry(cache,"key1", "value1");
		addEntry(cache,"key2", "value2");
		addEntry(cache,"key3", "value3");
		addEntry(cache,"key4", "value4");
		addEntry(cache,"key5", "value5");
	}
	
	public static void listEntries(Cache<Object, Object> cache){
		System.out.println("Keys: "+cache.keySet());
	}
	
	private static void addEntry(Cache<Object, Object> cache, String key, String value) {
		if(!cache.containsKey(key)) {
			cache.put(key, value);
		} else {
			System.out.println("Key [" + key + "] already present in cache!"); 
		}
	}
	
	public static void removeAllEntries(Cache<Object, Object> cache) {
		cache.clear();
	}
	
	public static void removeEntry(Cache<Object, Object> cache, String key) {
		if(cache.containsKey(key)) {
			cache.evict(key);
			System.out.println("Removed " + key + " from cache!");
		} 
	}
	
	public static void main(String[] args) throws IOException {
		DefaultCacheManager manager = new DefaultCacheManager(CONFIG_NAME);
		Cache<Object, Object> cache = manager.getCache();
		TestCustomCacheListener listener = new TestCustomCacheListener();
		cache.addListener(listener);
		
		System.out.println("Before: " + cache.get("key1"));
		removeEntry(cache, "key1");
		System.out.println("After: " + cache.get("key1"));

//		System.out.println(cache.get("key1"));
		
//		addEntries(cache);
		listEntries(cache);
		
//		removeAllEntries(cache);
		
		cache.stop();
	}
	
}
