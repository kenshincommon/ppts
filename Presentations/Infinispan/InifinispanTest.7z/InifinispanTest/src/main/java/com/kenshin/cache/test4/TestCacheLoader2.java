package com.kenshin.cache.test4;

import java.io.IOException;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;

public class TestCacheLoader2 {

	private static final String CONFIG_NAME = "config2-cache-Loader.xml";
	
	public static void listEntries(Cache<Object, Object> cache){
		System.out.println("Keys: "+cache.keySet());
	}
	
	public static void addEntry(Cache<Object, Object> cache, String key, String value) {
		if(!cache.containsKey(key)) {
			cache.put(key, value);
		} else {
			System.out.println("Key [" + key + "] already present in cache!"); 
		}
	}
	
	public static void removeAllEntries(Cache<Object, Object> cache) {
		cache.clear();
	}
	
	public static void removeEntry(Cache<Object, Object> cache, String key) {
		if(cache.containsKey(key)) {
			cache.evict(key);
			System.out.println("Removed " + key + " from cache!");
		} 
	}
	
	public static void main(String[] args) throws IOException {
		DefaultCacheManager manager = new DefaultCacheManager(CONFIG_NAME);
		Cache<Object, Object> cache1 = manager.getCache("cache1");
		Cache<Object, Object> cache2 = manager.getCache("cache2");
		
		addEntry(cache1, "C1-key1", "random value1");
		addEntry(cache1, "C1-key2", "random value2");

		System.out.println("Value from cache1 is: " + cache2.get("C1-key2"));
		
		listEntries(cache1);
		listEntries(cache2);
		
//		removeAllEntries(cache1);
		
		cache1.stop();
		cache2.stop();
	}
	
}
