package com.kenshin.cache.test4;

import org.infinispan.notifications.Listener;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryActivated;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryPassivated;
import org.infinispan.notifications.cachelistener.event.CacheEntryActivatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryPassivatedEvent;

@Listener
public class TestCustomCacheListener {

	@CacheEntryPassivated
	public void addEntry(CacheEntryPassivatedEvent<Object, Object> evt) {
		if (evt.isPre()) {
			System.out.println("Going to passivate: " + evt.getKey());
		} else {
			System.out.println("Passivated: " + evt.getKey());
		}
	}

	@CacheEntryActivated
	public void removeEntry(CacheEntryActivatedEvent<Object, Object> evt) {
		if (evt.isPre()) {
			System.out.println("Going to activate: " + evt.getKey());
		} else {
			System.out.println("Activated: " + evt.getKey());
		}
	}

}
