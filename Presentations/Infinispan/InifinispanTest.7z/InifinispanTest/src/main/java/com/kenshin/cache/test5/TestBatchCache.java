package com.kenshin.cache.test5;

import org.infinispan.Cache;
import org.infinispan.configuration.cache.Configuration;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.transaction.TransactionMode;

public class TestBatchCache {

	public static void main(String[] args) {
		DefaultCacheManager manager = new DefaultCacheManager();
		
		Configuration defaultCacheConfig = manager.getDefaultCacheConfiguration();
		Configuration programaticConfig = new ConfigurationBuilder()
				.read(defaultCacheConfig).invocationBatching().enable().transaction()
				.transactionMode(TransactionMode.TRANSACTIONAL).build();
		
		String cacheName = "newCacheConfig";
		manager.defineConfiguration(cacheName, programaticConfig);
		Cache<Object, Object> cache = manager.getCache(cacheName);
		
		//commit
		cache.startBatch();
		cache.put("key1", "value1");
		cache.put("key2", "value2");
		cache.put("key3", "value3");
		listEntries(cache);
		cache.endBatch(true);

		//rollback
		cache.startBatch();
		cache.put("key4", "value4");
		cache.put("key5", "value5");
		listEntries(cache);
		cache.endBatch(false);		
		listEntries(cache);
		
		cache.stop();
	}
	
	public static void listEntries(Cache<Object,Object> cache){
		System.out.println(cache.keySet());
	}
	
}
