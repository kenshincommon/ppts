package com.kenshin.cache.test6;

import java.io.IOException;

import org.infinispan.Cache;
import org.infinispan.configuration.cache.CacheMode;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.configuration.global.GlobalConfigurationBuilder;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.manager.EmbeddedCacheManager;

public class TestClusteringCache {

	public static final String CONFIG_NAME = "config3-clustering.xml";
	
	public static void main(String[] args) throws IOException {
		DefaultCacheManager manager = new DefaultCacheManager(CONFIG_NAME);
		Cache<Object, Object> cache = manager.getCache("clusteredCache1");
//		EmbeddedCacheManager manager = createCacheManagerProgramatically();
//		Cache<Object, Object> cache = manager.getCache();
		
		cache.put("key1", "value1");
		cache.put("key2", "value2");
		cache.put("key3", "value3");
 
		cache.put("key4", "value4");
		cache.put("key5", "value5");
		listEntries(cache);
		
		System.out.println("Waiting 10 seconds");
		sleep(10000);
		cache.remove("key1");
		cache.remove("key2");
		
		//cache.stop();
		//manager.stop();
	}
	
	public static void listEntries(Cache<Object,Object> cache){
		System.out.println(cache.keySet());
	}


	public static void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
public static EmbeddedCacheManager createCacheManagerProgramatically() {
   return new DefaultCacheManager(
      GlobalConfigurationBuilder.defaultClusteredBuilder()
         .transport().addProperty("configurationFile", "jgroups-tcp.xml")
         .build(),
      new ConfigurationBuilder()
         .clustering().cacheMode(CacheMode.REPL_SYNC)
         .build()
   );
}
	
}
