package com.kenshin.cache.test7;

import java.io.IOException;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;

public class TestClusterCache2 {

	public static final String CONFIG_NAME = "config5-clustering-stats.xml";
	
	public static void main(String[] args) throws IOException {
		DefaultCacheManager manager = new DefaultCacheManager(CONFIG_NAME);
		Cache<Object, Object> cache = manager.getCache("clusteredCache1");
		
		//sleep(5000);
		listEntries(cache);
		
		System.out.println("Waiting 10 seconds");
		sleep(10000);
		listEntries(cache);
		
	}

	public static void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void listEntries(Cache<Object,Object> cache){
		System.out.println(cache.keySet());
	}
	
}
