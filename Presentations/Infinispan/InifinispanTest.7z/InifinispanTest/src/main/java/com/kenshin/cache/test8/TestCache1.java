package com.kenshin.cache.test8;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.util.concurrent.NotifyingFuture;


public class TestCache1 {

	public static void main(String[] args) {
		DefaultCacheManager manager = new DefaultCacheManager();
		Cache<Object, Object> cache = manager.getCache();
		List<NotifyingFuture<Object>> list = new ArrayList<NotifyingFuture<Object>>();
		NotifyingFuture<Object> nf1 = cache.putAsync("key1", "value1");
		NotifyingFuture<Object> nf2 = cache.putAsync("key2", "value1");
		NotifyingFuture<Object> nf3 = cache.putAsync("key3", "value1");
		NotifyingFuture<Object> nf4 = cache.putAsync("key4", "value1");
		NotifyingFuture<Object> nf5 = cache.putAsync("key5", "value1");
		list.add(nf1);
		list.add(nf2);
		list.add(nf3);
		list.add(nf4);
		list.add(nf5);
		
		listEntries(cache);
		sleep(5000);
		listEntries(cache);
		
		for(NotifyingFuture<Object> future : list) {
			try {
				future.get();
			} catch (Exception e) {
				e.printStackTrace();
				//a cache setup failed !!!
			}
		}
		
		cache.stop();
	}
	
	public static void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void listEntries(Cache<Object,Object> cache){
		System.out.println(cache.keySet());
	}
	
}
