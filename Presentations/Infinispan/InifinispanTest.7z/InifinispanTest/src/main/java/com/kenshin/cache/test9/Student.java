package com.kenshin.cache.test9;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.ProvidedId;
import org.hibernate.search.annotations.Store;

@ProvidedId @Indexed
public class Student {

	@Field(store=Store.YES)
	private String fName = null;
	
	@Field(store=Store.YES)
	private String lName = null;
	
	public Student(String fName, String lName) {
		this.fName = fName;
		this.lName = lName;
	}
	
	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}
	@Override
	public String toString() {
		return "Student [fName=" + fName + ", lName=" + lName + "]";
	}
	
}
