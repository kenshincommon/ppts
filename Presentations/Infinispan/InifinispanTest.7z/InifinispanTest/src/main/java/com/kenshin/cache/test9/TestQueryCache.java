package com.kenshin.cache.test9;

import java.io.IOException;
import java.util.List;

import org.apache.lucene.search.Query;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.infinispan.Cache;
import org.infinispan.configuration.cache.Configuration;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.query.CacheQuery;
import org.infinispan.query.Search;
import org.infinispan.query.SearchManager;

public class TestQueryCache {

	
	public static void main(String[] args) throws IOException {
		
		ConfigurationBuilder builder = new ConfigurationBuilder();
		builder.indexing().enable().indexLocalOnly(true);
		Configuration cfg = builder.build();
		
		DefaultCacheManager manager = new DefaultCacheManager(cfg);
		Cache<Object, Object> cache = manager.getCache();
		cache.put("key1", new Student("testFName1", "testLName1"));
		cache.put("key2", new Student("testFName2", "testLName2"));
		cache.put("key3", new Student("testFName3", "testLName3"));
		cache.put("key4", new Student("testFName4", "testLName4"));
		
		listEntries(cache);
		
		SearchManager searchManager = Search.getSearchManager(cache);
		QueryBuilder queryBuilder = searchManager.buildQueryBuilderForClass(Student.class).get();
		Query luceneQuery = queryBuilder.keyword().onField("fName")
				.matching("testFName3").createQuery();
		CacheQuery queryResult = searchManager.getQuery(luceneQuery, Student.class);
		List<Object> results = queryResult.list();
		System.out.println(results);
		
		cache.stop();
	}

	public static void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void listEntries(Cache<Object,Object> cache){
		System.out.println(cache.keySet());
	}
	
}
