package test.flexjson;

import java.io.StringWriter;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;

public class FlexjsonUsage {

	public static void main(String[] args) {
		
		/**
		 * create JSON objects
		 */
		createJSON();
		
		/**
		 * pasrse JSON objects
		 */
		parseJSON();
	}
	
	public static void createJSON(){
		StringWriter writer = new StringWriter();
		JSONSerializer serializer = new JSONSerializer();
		serializer.exclude("age");
		Student student = new Student();
		student.setFirstName("fName");
		student.setLastName("lName");
		serializer.serialize(student, writer);
		System.out.println("JSON=[" + writer.toString() + "]");
	}
	
	public static void parseJSON(){
		String input = "{\"class\":\"test.flexjson.Student\",\"firstName\":\"fName\",\"lastName\":\"lName\"}";
		JSONDeserializer<Student> deserializer = new JSONDeserializer<>();
		Student student = deserializer.deserialize(input);
		System.out.println("Student=[" + student + "]");
	}
	
}
