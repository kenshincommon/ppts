package test.gson;

import com.google.gson.annotations.Since;

public class Actor {

	@Since(1.0) private String fName = null;
	
	@Since(2.0) private String lName = null;
	
	@Since(3.0) private String city = null;

	public Actor(){}
	
	public Actor(String fName, String lName, String city){
		setfName(fName);
		setlName(lName);
		setCity(city);
	}
	
	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Actor [fName=" + fName + ", lName=" + lName + ", city=" + city
				+ "]";
	}
	
}
