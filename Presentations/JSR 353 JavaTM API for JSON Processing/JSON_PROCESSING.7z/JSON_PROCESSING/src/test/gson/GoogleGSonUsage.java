package test.gson;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class GoogleGSonUsage {

	public static void main(String[] args) {
		
		/**
		 * create JSON objects
		 */
		createGSON();
		
		/**
		 * user versioning
		 */
		createGSONVersioning();
	}
	
	public static void createGSONVersioning(){
		Actor actor = new Actor("fName1","lName1","city1");
		Gson gson = new GsonBuilder().setPrettyPrinting().setVersion(1.5).create();
		System.out.println("Actor1 =[" + gson.toJson(actor) + "]");
		Gson gson2 = new GsonBuilder().setPrettyPrinting().setVersion(3.5).create();
		System.out.println("Actor2 =[" + gson2.toJson(actor) + "]");
	}
	
	public static void createGSON() {
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("key1", "value1");
		jsonObject.addProperty("key2", 2);
		jsonObject.addProperty("key3", false);
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String jsonOutput = gson.toJson(jsonObject);
		System.out.println("jsonOutput=[" + jsonOutput + "]");
	}
	
}
