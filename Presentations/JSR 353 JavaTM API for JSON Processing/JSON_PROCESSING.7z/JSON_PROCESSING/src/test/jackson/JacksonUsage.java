package test.jackson;

import java.io.IOException;
import java.io.StringWriter;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;

public class JacksonUsage {

	public static void main(String[] args) throws JsonParseException, IOException {
		
		/**
		 * created JSON objects
		 */
		createJSON();
		
	}
	
	public static void createJSON() throws IOException {
		StringWriter writer = new StringWriter();
		JsonFactory factory = new JsonFactory();
		JsonGenerator g = factory.createGenerator(writer);

		g.writeStartObject();
		g.writeObjectFieldStart("name");
		g.writeStringField("first", "Joe");
		g.writeStringField("last", "Doe");
		g.writeEndObject();
		g.writeBooleanField("verified", false);
		g.writeFieldName("userImage");
		g.writeBinary("binary data".getBytes());
		g.writeEndObject();

		g.close();
		System.out.println("writer=[" + writer.toString() + "]");
	}
	
}
