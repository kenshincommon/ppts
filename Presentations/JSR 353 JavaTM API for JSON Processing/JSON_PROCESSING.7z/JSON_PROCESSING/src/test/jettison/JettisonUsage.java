package test.jettison;

import java.io.IOException;
import java.io.StringWriter;

import javax.xml.stream.XMLStreamException;

import org.codehaus.jettison.AbstractXMLStreamWriter;
import org.codehaus.jettison.mapped.MappedNamespaceConvention;
import org.codehaus.jettison.mapped.MappedXMLStreamWriter;

public class JettisonUsage {

	public static void main(String[] args) throws XMLStreamException, IOException {

		/**
		 * create JSON
		 */
		createJSON();
	}

	public static void createJSON() throws XMLStreamException, IOException {
		StringWriter stringWriter = new StringWriter();
		MappedNamespaceConvention con = new MappedNamespaceConvention();
		AbstractXMLStreamWriter w = new MappedXMLStreamWriter(con, stringWriter);
		w.writeStartDocument();
		w.writeStartElement("Products");
		
		w.writeStartElement("Product1");
		w.writeCharacters("NeedForSpeed");
		w.writeEndElement();
		w.writeStartElement("Product2");
		w.writeCharacters("Crysis");
		w.writeEndElement();
		
		w.writeEndElement();
		w.writeEndDocument();
		w.close();
		stringWriter.close();
		System.out.println(stringWriter.toString());
	}

}
