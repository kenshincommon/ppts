package test.jsonlib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSON;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import net.sf.json.JsonConfig;
import net.sf.json.util.PropertyFilter;

public class JsonLibUsage {

	public static void main(String[] args) {
		/**
		 * use JSONSerializer
		 */
		useSerializer();
		
		/**
		 * use JSONObject
		 */
		createJSONObjects();
		
		/**
		 * use Complex domain classes
		 */
		createComplexJSONObjects();
		
		/**
		 * loads JSON into domain classes
		 */
		loadJSONIntoBeans();
		
		/**
		 * loads more JSON into domain classes 
		 */
		loadJSONIntoComplexBeans();
		
		/**
		 * loads JSON into domain classes
		 * with fukter
		 */
		loadJSONIntoBeansWithFilter();
	}
	
	public static void loadJSONIntoComplexBeans(){
		String jsonInput = "{'studList':[{'firstName':'John','lastName':'Wayne','age':35},{'firstName':'FNAME','lastName':'LNAME','age':22}]}";
		JSONObject jsonObj = JSONObject.fromObject(jsonInput);
		Map<String, Class<?>> classMap = new HashMap<String, Class<?>>();
		classMap.put("studList", Student.class);
		StudentList list = (StudentList)JSONObject.toBean(jsonObj, StudentList.class, classMap);
		System.out.println("StudentList=[" + list + "]");
	}
	
	public static void loadJSONIntoBeansWithFilter(){
		String jsonInput = "{'firstName':'John','lastName':'Wayne','age':35}";
		JsonConfig jsonConfig = new JsonConfig();  
		jsonConfig.setRootClass( Student.class );  
		jsonConfig.setJavaPropertyFilter( new PropertyFilter(){  
		   public boolean apply( Object source, String name, Object value ) {  
		      if( "firstName".equals( name ) || "lastName".equals( name ) ){  
		         return true;  
		      }  
		      return false;  
		   }  
		});
		Student student = (Student)JSONObject.toBean(JSONObject.fromObject(jsonInput), jsonConfig);
		System.out.println("student filtered=[" + student + "]");
	}
	
	public static void loadJSONIntoBeans(){
		String jsonInput = "{'firstName':'John','lastName':'Wayne','age':35}";
		Student student = (Student)JSONObject.toBean(JSONObject.fromObject(jsonInput), Student.class);
		System.out.println("student=[" + student + "]");
	}
	
	public static void createComplexJSONObjects(){
		Student student = new Student("firstName", "lastName", 30);
		JSONObject jsonObject = JSONObject.fromObject( student );
		System.out.println("jsonObject2=[" + jsonObject + "]");
	}
	
	public static void createJSONObjects(){
		Map<String, Object> map = new HashMap<String, Object>();  
		map.put( "name", "json" );  
		map.put( "bool", Boolean.TRUE );  
		map.put( "int", new Integer(1) );  
		map.put( "arr", new String[]{"a","b"} );  
		map.put( "func", "function(i){ return this.arr[i]; }" );  
		  
		JSONObject jsonObject = JSONObject.fromObject( map );  
		System.out.println("jsonObject=[" + jsonObject  + "]"); 
	}
	
	public static void useSerializer(){
		Map<String,Object> props = new HashMap<String, Object>();
		List<String> myList = new ArrayList<String>();
		myList.add("obj1");
		myList.add("obj2");
		props.put("key1", "value1");
		props.put("key2", 2);
		props.put("key3", true);
		props.put("key4", myList);
		JSON json = JSONSerializer.toJSON(props);
		System.out.println("JSON=[" + json.toString() + "]");
	}
	
}
