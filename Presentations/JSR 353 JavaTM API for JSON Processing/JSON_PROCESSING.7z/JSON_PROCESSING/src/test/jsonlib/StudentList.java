package test.jsonlib;

import java.util.List;

public class StudentList {

	private List<Student> studList = null;

	public StudentList(){}
	
	public StudentList(List<Student> studList){
		this.studList = studList;
	}
	
	public List<Student> getStudList() {
		return studList;
	}

	public void setStudList(List<Student> studList) {
		this.studList = studList;
	}

	@Override
	public String toString() {
		return "StudentList [studList=" + studList + "]";
	}

}
