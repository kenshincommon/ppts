package test.jsonmarshaller;

import com.twolattes.json.Entity;
import com.twolattes.json.Value;

@Entity
class Author {
	@Value
	private String firstName;
	
	@Value
	private String lastName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Author [firstName=" + firstName + ", lastName=" + lastName
				+ "]";
	}
	
}