package test.jsonmarshaller;

import java.util.ArrayList;
import java.util.List;

import com.twolattes.json.Json;
import com.twolattes.json.Json.Value;
import com.twolattes.json.Marshaller;
import com.twolattes.json.TwoLattes;

public class JSonMarshallerUsage {

	public static void main(String[] args) {
		
		/**
		 * create JSON objects
		 */
		createJSON();
		
		/**
		 * parse JSON objects
		 */
		parseJSON();
	}
	
	public static void createJSON(){
		Book book = new Book();
		book.setIsbn("ISBN_VALUE");
		book.setTitle("Title_VALUE");
		List<Author> authors = new ArrayList<Author>();
		Author author = new Author();
		author.setFirstName("fName");
		author.setLastName("lName");
		authors.add(author);
		book.setAuthors(authors);
		
		Marshaller<Book> m = TwoLattes.createMarshaller(Book.class);
		Value value = m.marshall(book);
		System.out.println("JSON=<<" + value.toString() + ">>");
	}
	
	public static void parseJSON(){
		String jsonObj = "{\"isbn\":\"ISBN_VALUE\",\"title\":\"Title_VALUE\"}";
		Value value = Json.fromString(jsonObj);
		Marshaller<Book> m = TwoLattes.createMarshaller(Book.class);
		Book book = m.unmarshall(value);
		System.out.println("Book=[" + book + "]");
	}
	
}
