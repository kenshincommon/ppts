package test.jsonsimple;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

@SuppressWarnings("unchecked")
public class JsonSimpleUsage {

	public static void main(String[] args) {
		File systemFile = new File("test.json");

		/**
		 * create JSON file
		 */
		createJSONFile(systemFile);

		/**
		 * create JSON objects from java.util.Map
		 */
		Map<String, Object> obj = new HashMap<String, Object>();
		obj.put("name", "foo");
		obj.put("integer", new Integer(100));
		obj.put("double", new Double(1000.21));
		obj.put("boolean", new Boolean(true));
		obj.put("nothing", null);
		createJSONTextFromMap(obj);
		
		/**
		 * load JSON objects from file
		 */
		loadDataFromJSON(systemFile);
		
		/**
		 * merge 2 JSON objects
		 */
		JSONObject obj1 = new JSONObject();
		obj1.put("key1", "value1");
		JSONObject obj2 = new JSONObject();
		obj1.put("key2", "value2");
		mergeJSONObjects(obj1, obj2);
		
		/**
		 * create JSON from complex objects
		 */
		createComplexJSON();
		
	}
	
	public static void createComplexJSON() {
		JSONObject obj = new JSONObject();
		JSONArray persons = new JSONArray();
		persons.add(new Person("Ionut", "Daniel",29));
		persons.add(new Person("Kenshin", "Batosai",29));
		obj.put("persons",persons);
		System.out.println("COMPLEX JSON [" + JSONValue.toJSONString(obj) + "]");
	}

	public static void mergeJSONObjects(JSONObject obj1, JSONObject obj2) {
		obj1.putAll(obj2);
		System.out.println("MERGED OBJECTS [" + obj1.toJSONString() + "]");
	}
	
	public static void loadDataFromJSON(File inputFile){
		JSONParser parser = new JSONParser();
		try {
			JSONObject jsonObject = (JSONObject)parser.parse(new FileReader(inputFile));
			String name = (String) jsonObject.get("name");
			Long var1 = (Long) jsonObject.get("integer");
			Double var2 = (Double) jsonObject.get("double");
			Boolean var3 = (Boolean) jsonObject.get("boolean");
			JSONArray tab = (JSONArray) jsonObject.get("myLists");
			Iterator<String> iterator = tab.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
			System.out.println("NAME=[" + name + "]");
			System.out.println("Integer=[" + var1 + "]");
			System.out.println("Double=[" + var2 + "]");
			System.out.println("Boolean=[" + var3 + "]");
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}
	
	public static void createJSONTextFromMap(Map<String, Object> values) {
		String jsonText = JSONValue.toJSONString(values);
		System.out.println("JSON_TEXT =[" + jsonText + "]");
	}

	public static void createJSONFile(File outputFile) {
		JSONObject obj = new JSONObject();
		obj.put("name", "foo");
		obj.put("integer", new Integer(100));
		obj.put("double", new Double(1000.21));
		obj.put("boolean", new Boolean(true));
		obj.put("nothing", null);

		JSONArray list = new JSONArray();
		list.add("msg 1");
		list.add("msg 2");
		list.add("msg 3");
		obj.put("myLists", list);

		System.out.println("JSON [" +obj.toJSONString() + "]");
		
		writeJSONtoFile(outputFile, obj);
	}

	private static void writeJSONtoFile(File outputFile, JSONObject obj) {
		FileWriter file = null;
		try {
			file = new FileWriter(outputFile);
			file.write(obj.toJSONString());
			file.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
