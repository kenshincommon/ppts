package test.jsonsimple;

import org.json.simple.JSONAware;
import org.json.simple.JSONObject;

public class Person implements JSONAware {

	private String firstName = null;

	private String lastName = null;

	private int age = 20;

	public Person(String firstName, String lastName, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}

	@Override
	public String toJSONString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		sb.append(JSONObject.escape("firstName"));
		sb.append(":");
		sb.append("\"" + JSONObject.escape(firstName) + "\"");
		sb.append(",");
		sb.append(JSONObject.escape("lastName"));
		sb.append(":");
		sb.append(lastName);
		sb.append(",");
		sb.append(JSONObject.escape("age"));
		sb.append(":");
		sb.append(age);
		sb.append("}");
		return sb.toString();
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
