package test.jsr353;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.apache.commons.io.IOUtils;

public class TestCreateObject {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		JsonObjectBuilder objBuilder = Json.createObjectBuilder();
		objBuilder.add("name", "name goes here");
		objBuilder.add("firstName", "firstname goes here");
		objBuilder.add("lastName", "lastname goes here");
		objBuilder.add("age", 30);
		
		JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
		arrayBuilder.add(Json.createObjectBuilder().add("number", "number goes here 1").add("prefix", "prefix goes here 1").build());
		arrayBuilder.add(Json.createObjectBuilder().add("number", "number goes here 2").add("prefix", "prefix goes here 2").build());
		objBuilder.add("phone-numbers", arrayBuilder);
		
		JsonObject build = objBuilder.build();
		String jsonContent = build.toString();
		System.out.println(jsonContent); 
		
		IOUtils.write(jsonContent, new FileOutputStream("test2.json"));
	}
	
}
