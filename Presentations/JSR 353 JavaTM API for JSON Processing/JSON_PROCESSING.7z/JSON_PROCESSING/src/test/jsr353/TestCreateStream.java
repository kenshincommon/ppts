package test.jsr353;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.json.Json;
import javax.json.stream.JsonGenerator;
import javax.json.stream.JsonGeneratorFactory;

import org.apache.commons.io.IOUtils;

public class TestCreateStream {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		Map<String, Object> properties = new HashMap<String, Object>(1);
		properties.put(JsonGenerator.PRETTY_PRINTING, true);
		JsonGeneratorFactory factory = Json.createGeneratorFactory(properties);
		StringWriter writer = new StringWriter();
		JsonGenerator generator = factory.createGenerator(writer);

		generator.writeStartObject().write("name", "Kenshin")
				.writeStartObject("address")
					.writeNull("type")
					.write("street", "Street goes here")
					.write("city", "City goes here")
				.writeEnd()
				.writeStartArray("phone-numbers")
					.writeStartObject()
						.write("number", "number goes here")
						.write("prefix", "prefix here")
					.writeEnd()
				.writeStartObject()
					.write("number", "number goes here")
					.write("prefix", "prefix here")
				.writeEnd().writeEnd().writeEnd().close();

		System.out.println(writer);
		
		IOUtils.write(writer.toString(), new FileOutputStream("test1.json"));
		
	}
	
}
