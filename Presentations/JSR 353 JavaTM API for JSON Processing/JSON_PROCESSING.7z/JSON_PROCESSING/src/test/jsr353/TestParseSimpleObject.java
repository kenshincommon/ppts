package test.jsr353;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

import org.apache.commons.io.IOUtils;

public class TestParseSimpleObject {

	public static void main(String[] args) {
		FileInputStream inputStream = null;
		JsonReader reader = null;
		try {
			inputStream = new FileInputStream("test2.json");
			reader = Json.createReader(inputStream);

			JsonObject allObject = reader.readObject();
			System.out.println("Name: " + allObject.getString("name"));
			System.out.println("firstName: " + allObject.getString("firstName"));
			System.out.println("lastName: " + allObject.getString("lastName"));
			System.out.println("age: " + allObject.getInt("age"));
			
			JsonArray phonesArray = allObject.getJsonArray("phone-numbers");
			JsonObject phoneObject = null;
			if(phonesArray != null) {
				System.out.println("PHONE NUMBERS: ");
				for (int i = 0; i < phonesArray.size(); i++) {
					phoneObject = phonesArray.getJsonObject(i);
					if(phoneObject != null) {
						System.out.print("Number: " + phoneObject.getString("number"));
						System.out.println(" --> Prefix: " + phoneObject.getString("prefix"));
					}
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(reader);
			IOUtils.closeQuietly(inputStream);
		}
	}
	
	
}
