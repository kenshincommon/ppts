package test.jsr353;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import org.apache.commons.io.IOUtils;

public class TestParseStream {

	public static void main(String[] args) {
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream("test1.json");
			JsonParser parser = Json.createParser(inputStream);
			Event event = null;

			// find "address" key
			while (parser.hasNext()) {
				event = parser.next();
				if (event == Event.KEY_NAME && "address".equals(parser.getString())) {
					event = parser.next();
					break;
				}
			}

			// Output contents of "address" object
			while (event != Event.END_OBJECT) {
				switch (event) {
				case KEY_NAME: {
					System.out.print(parser.getString());
					System.out.print(" = ");
					break;
				}
				case VALUE_FALSE: {
					System.out.println(false);
					break;
				}
				case VALUE_NULL: {
					System.out.println("null");
					break;
				}
				case VALUE_NUMBER: {
					if (parser.isIntegralNumber()) {
						System.out.println(parser.getInt());
					} else {
						System.out.println(parser.getBigDecimal());
					}
					break;
				}
				case VALUE_STRING: {
					System.out.println(parser.getString());
					break;
				}
				case VALUE_TRUE: {
					System.out.println(true);
					break;
				}
				default: {
				}
				}
				event = parser.next();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

}
