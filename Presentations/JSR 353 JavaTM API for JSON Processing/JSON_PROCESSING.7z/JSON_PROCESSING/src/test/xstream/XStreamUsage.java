package test.xstream;

import java.io.StringReader;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;

public class XStreamUsage {

	public static void main(String[] args) {
		
		/**
		 * creates JSON objects
		 */
		createJSON();
		
		/**
		 * parses JSON objects
		 */
		parseJSON();
		
	}
	
	public static void parseJSON(){
		String jsonObj = "{\"student\":{\"firstName\":\"fName\",\"lastName\":\"lname\",\"age\":33}}";
		XStream xstream = new XStream(new JettisonMappedXmlDriver());
        xstream.setMode(XStream.NO_REFERENCES);
        xstream.alias("student", Student.class);
        Student student = (Student)xstream.fromXML(new StringReader(jsonObj));
        System.out.println("Student=[" + student + "]");
	}
	
	public static void createJSON(){
		Student student = new Student("fName", "lname", 33);
		XStream xstream = new XStream(new JettisonMappedXmlDriver());
        xstream.setMode(XStream.NO_REFERENCES);
        xstream.alias("student", Student.class);
        System.out.println("JSON=[" + xstream.toXML(student) + "]");
	}
	
}
