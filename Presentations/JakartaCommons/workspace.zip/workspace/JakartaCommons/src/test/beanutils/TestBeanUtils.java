package test.beanutils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.beanutils.WrapDynaBean;
import org.apache.commons.beanutils.WrapDynaClass;

@SuppressWarnings("unchecked")
public class TestBeanUtils {

	public static void main(String[] args) throws Exception {
		User user1 = new User();
		User user2 = new User();
		
		BeanUtils.setProperty(user1, "nume", "Kenshin");
		BeanUtils.setProperty(user1, "prenume", "Ruroni");
		System.out.println("User1: " + user1);
		
		BeanUtils.copyProperties(user2, user1);
		System.out.println("User2: " + user2);
		
		System.out.println(BeanUtils.describe(user2));
		
		DynaProperty[] properties = WrapDynaClass.createDynaClass(User.class).getDynaProperties();
		System.out.println(Arrays.asList(properties));
		
		DynaProperty[] dynaProperties = new WrapDynaBean(user1).getDynaClass().getDynaProperties();
		System.out.println(Arrays.asList(dynaProperties));
	
		System.out.println("PROPERTY: " + PropertyUtils.getProperty(user1, "nume"));
		System.out.println("IS_WRITE: " + PropertyUtils.isWriteable(user1, "prenume"));
		System.out.println("TYPE: " + PropertyUtils.getPropertyType(user1, "prenume"));
	
		System.out.println(PropertyUtils.getPropertyDescriptor(user1, "nume").getReadMethod());
		
		BeanComparator bComparator = new BeanComparator("prenume");
		List<User> myList = new Vector<User>();
		myList.add(new User("U3", "C"));
		myList.add(new User("U2", "B"));
		myList.add(new User("U1", "A"));
		Collections.sort(myList, bComparator); 
		System.out.println(myList);
	}

}
