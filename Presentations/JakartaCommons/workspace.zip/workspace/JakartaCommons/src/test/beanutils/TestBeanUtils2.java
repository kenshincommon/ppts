package test.beanutils;

import org.apache.commons.beanutils.BasicDynaBean;
import org.apache.commons.beanutils.BasicDynaClass;
import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.beanutils.BeanPredicate;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.functors.AllPredicate;
import org.apache.commons.collections.functors.AnyPredicate;
import org.apache.commons.collections.functors.EqualPredicate;
import org.apache.commons.collections.functors.NotNullPredicate;

public class TestBeanUtils2 {

	public static void main(String[] args) throws Exception {
		User user1 = new User();
		Predicate notNull = new BeanPredicate( "nume", NotNullPredicate.getInstance() );
		System.out.println("Test1: " + notNull.evaluate(user1));//false
		
		User user2 = new User("Bill","Jeremy");
		Predicate equals = new BeanPredicate("nume",EqualPredicate.getInstance("Bill"));
		System.out.println("Test2: " + equals.evaluate(user2));//true
		
		User user3 = new User("Bill_","Jeremy");
		Predicate allValids = new AllPredicate(new Predicate[]{notNull, equals});
		System.out.println("Test3: " + allValids.evaluate(user3));//false

		Predicate anyValids = new AnyPredicate(new Predicate[]{notNull, equals});
		System.out.println("Test4: " + anyValids.evaluate(user3));//true
		
		System.out.println("Test5: " + new BeanMap(user3));
		
		DynaProperty[] beanProperties = new DynaProperty[]{
			    new DynaProperty("nume", String.class),
			    new DynaProperty("count", Integer.class),
			    new DynaProperty("votes", Long.class) };
		
		BasicDynaClass dynamicClass = new BasicDynaClass("myInstance", BasicDynaBean.class, beanProperties);
		DynaBean newInstance = dynamicClass.newInstance();
		newInstance.set("nume", "Ninja");
		newInstance.set("count", 10);
		newInstance.set("votes", Long.valueOf(9));
		System.out.println("NUME: " + newInstance.get("nume"));
	}

}
