package test.beanutils;

import org.apache.commons.lang.builder.ToStringBuilder;

public class User {
	
	private String nume = null;
	private String prenume = null;

	public User(){}
	public User(String nume, String prenume){
		setNume(nume);
		setPrenume(prenume);
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getPrenume() {
		return prenume;
	}
	public void setPrenume(String prenume) {
		this.prenume = prenume;
	}
	public String toString(){
		return ToStringBuilder.reflectionToString(this);
	}

}
