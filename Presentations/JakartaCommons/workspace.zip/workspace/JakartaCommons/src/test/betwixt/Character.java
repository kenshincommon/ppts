package test.betwixt;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Character {

	private String description = null;
	private String name = null;
	private String protagonist = null;
	
	public Character(){}
	public Character(String description, String name, 
			String protagonist){
		setDescription(description);
		setName(name);
		setProtagonist(protagonist);
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProtagonist() {
		return protagonist;
	}
	public void setProtagonist(String protagonist) {
		this.protagonist = protagonist;
	}
	public String toString(){
		return ToStringBuilder.reflectionToString(this);
	}
	
}
