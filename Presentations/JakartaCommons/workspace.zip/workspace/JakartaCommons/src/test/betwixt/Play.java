package test.betwixt;

import java.util.List;
import java.util.Vector;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Play {
	
	private String author = null;
	private List<Character> characters = null;
	
	private String genre = null;
	private Integer year = null;
	private String language = null;
	
	public Play(){
		characters = new Vector<Character>();
	}
	
	public Play(String author, List<Character> characters){
		setAuthor(author);
		setCharacters(characters);
	}
	
	public Play(String author, List<Character> characters, 
			String genre, Integer year, String language){
		setAuthor(author);
		setCharacters(characters);
		setGenre(genre);
		setYear(year);
		setLanguage(language);
	}
	public void addCharacter(Character character){
		this.characters.add(character);
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public List<Character> getCharacters() {
		return characters;
	}
	public void setCharacters(List<Character> characters) {
		this.characters = characters;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String toString(){
		return ToStringBuilder.reflectionToString(this);
	}
}
