package test.betwixt;

import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Vector;

import org.apache.commons.betwixt.io.BeanReader;
import org.apache.commons.betwixt.io.BeanWriter;


public class TestBetwixt1 {

	public static void main(String[] args) throws Exception {
		Character character1 = new Character("description1","name1","protagonis1");
		Character character2 = new Character("description2","name2","protagonis2");
		Character character3 = new Character("description3","name3","protagonis3");
		
		List<Character> characters = new Vector<Character>();
		characters.add(character1);
		characters.add(character2);
		characters.add(character3);
		
		Play play = new Play("author1", characters);
		play.setGenre("Drama");
		play.setYear(1800);
		play.setLanguage("romanian");
		
		FileWriter fWriter = new FileWriter("output.xml");
		BeanWriter beanWriter = new BeanWriter(fWriter);
		beanWriter.setEndOfLine( "\r\n" );
		beanWriter.setIndent( "\t" );
		beanWriter.enablePrettyPrint();
		beanWriter.write(play);
		beanWriter.close();
		
		BeanReader reader = new BeanReader();
		reader.registerBeanClass("play", Play.class);
		reader.registerBeanClass("Play/characters/Character", Character.class);
		Play playReaded = (Play)reader.parse(new File("output.xml"));
		System.out.println("Readed: " + playReaded);
	}

}
