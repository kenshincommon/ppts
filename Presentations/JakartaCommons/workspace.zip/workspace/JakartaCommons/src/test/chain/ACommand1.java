package test.chain;

import org.apache.commons.chain.Command;
import org.apache.commons.chain.Context;

@SuppressWarnings("unchecked")
public class ACommand1 implements Command {

	@Override
	public boolean execute(Context ctx) throws Exception {
		System.out.println("ACommand1.execute");
		String property = (String) ctx.get("property");
		System.out.println("A command: " + property);
		ctx.put("new_property", "new property value");
		return false;//resume
	}

}
