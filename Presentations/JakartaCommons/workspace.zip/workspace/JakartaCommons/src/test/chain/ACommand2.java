package test.chain;

import org.apache.commons.chain.Command;
import org.apache.commons.chain.Context;

public class ACommand2 implements Command {

	@Override
	public boolean execute(Context ctx) throws Exception {
		System.out.println("ACommand2.execute");
		String property = (String) ctx.get("property");
		System.out.println("A command2 PROP: " + property);
		String new_property = (String) ctx.get("new_property");
		System.out.println("A command2 NEW PROP: " + new_property);
		return true;//stop
	}
	
}
