package test.chain;

import java.io.File;
import java.net.URL;

import org.apache.commons.chain.Catalog;
import org.apache.commons.chain.Command;
import org.apache.commons.chain.Context;
import org.apache.commons.chain.config.ConfigParser;
import org.apache.commons.chain.impl.CatalogFactoryBase;
import org.apache.commons.chain.impl.ContextBase;

@SuppressWarnings("all")
public class ChainStart {

	public static void main(String args[]) throws Exception {
		ChainStart cs = new ChainStart();
		ConfigParser parser = new ConfigParser();
		URL resource = new File("chain-config.xml").toURL();
		System.out.println("URL: " + resource);
		parser.parse(resource);
		Catalog catalog = CatalogFactoryBase.getInstance().getCatalog();
		Command command = catalog.getCommand("a-chain");
		Context context = new ContextBase();
		context.put("property", "a property value");
		boolean result = command.execute(context);
		System.out.println("RESULT: " + result);
		
		System.out.println("---------------");
		YourContext context2 = new YourContext();
		context2.setProperty("a property value");
		boolean result2 = command.execute(context);
		System.out.println("RESULT: " + result2);		
		
	}
	
}
