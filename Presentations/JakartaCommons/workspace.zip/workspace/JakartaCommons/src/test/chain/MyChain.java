package test.chain;

import org.apache.commons.chain.impl.ChainBase;

public class MyChain extends ChainBase {
	public MyChain(){
		addCommand(new ACommand1());
		addCommand(new ACommand2());
	}

}
