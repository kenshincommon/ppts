package test.chain;

import org.apache.commons.chain.impl.ContextBase;

public class TestMyChain {

	public static void main(String[] args) throws Exception {
		MyChain chain = new MyChain();
		boolean execute = chain.execute(new ContextBase());
		System.out.println("Execute: " + execute);
		
	}

}
