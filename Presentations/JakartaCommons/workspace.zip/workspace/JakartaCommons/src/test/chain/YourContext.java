package test.chain;

import org.apache.commons.chain.impl.ContextBase;

@SuppressWarnings("serial")
public class YourContext extends ContextBase {

	private String property;

	public String getProperty() {
		return property;
	}
	public void setProperty(String string) {
		property = string;
	}
}
