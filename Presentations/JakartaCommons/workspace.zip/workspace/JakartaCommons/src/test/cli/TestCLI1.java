package test.cli;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;


public class TestCLI1 {

	//Main -l somefile.txt
	public static void main(String[] args) throws Exception {
		Options options = new Options();
		options.addOption( "l", "location", true, "location of configuration file");
		CommandLineParser parser = new BasicParser();
		CommandLine cmd = parser.parse(options, args);
		System.out.println( "location of the file is (" + cmd.getOptionValue("l") + ")");
		

	}

}
