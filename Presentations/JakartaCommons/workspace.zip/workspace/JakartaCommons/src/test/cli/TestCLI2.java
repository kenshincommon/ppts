package test.cli;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.lang.ArrayUtils;

@SuppressWarnings("rawtypes")
public class TestCLI2 {

	//java Main -l somefile.txt -f -d value1 value2 "left over"
	public static void main(String[] args) throws Exception {
        Options options = new Options();
        options.addOption("l", "location", true, "location of configuration file");

        Option option = new Option("f", "flag", false,"this is a flag");
        option.setOptionalArg(true);
        options.addOption(option);

        option = new Option("d", "define", true,"definition declaration");
        option.setArgs(2);
        options.addOption(option);
		
        CommandLineParser parser = new BasicParser();
        CommandLine cmd = parser.parse( options, args);
        String results[] = cmd.getOptionValues("d");
        System.out.println("RESULTS: " + ArrayUtils.toString(results));
        
        System.out.println("ARGS: " + ArrayUtils.toString(cmd.getArgs()));
        System.out.println("HAS E: " + cmd.hasOption('e'));//false
        List list = cmd.getArgList();
        if(list != null) {
            Iterator iter = list.iterator();
            while(iter.hasNext()) {
                System.out.println("Left over: " + iter.next().toString());
            }
        }
	}

}
