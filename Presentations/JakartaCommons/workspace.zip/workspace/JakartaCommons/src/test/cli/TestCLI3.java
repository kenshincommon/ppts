package test.cli;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PatternOptionBuilder;

@SuppressWarnings("static-access")
public class TestCLI3 {

	public static void main(String[] args) throws Exception {
		Options options = new Options();
        Option option = OptionBuilder.withLongOpt( "integer")
                          .hasArg()
                          .isRequired( false)
                          .withDescription( "integer option type" )
                          .withType( PatternOptionBuilder.NUMBER_VALUE)
                          .create( 'i' );
        options.addOption( option);
        CommandLineParser parser = new BasicParser();

        CommandLine cmd = parser.parse( options, args);
        Integer value = (Integer)cmd.getOptionObject("i");
        System.out.println( "Value is " + value.toString());
	}

}
