package test.codec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.BinaryCodec;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.net.URLCodec;

public class TestCodec1 {

	public static void main(String[] args) throws Exception {
		String chunk = "This is a text";
		byte[] encode = new Hex().encode(chunk.getBytes());
		System.out.println("HEX ENCODE: " + new String(encode));
		byte[] decode = new Hex().decode(encode);
		System.out.println("HEX DECODE: " + new String(decode));
		
		byte[] encodeBase64 = Base64.encodeBase64(chunk.getBytes());
		System.out.println("BASE64 ENCODE: " + new String(encodeBase64));
		byte[] decodeBase64 = Base64.decodeBase64(encodeBase64);
		System.out.println("BASE64 DECODE: " + new String(decodeBase64));
		
		String url = "http://www.example.org/code.jsp?foo=bar test";
		URLCodec urlCodec = new URLCodec();
		String encodedUrl = urlCodec.encode(url);
		System.out.println("URL ENCODE: " + encodedUrl);
		String decodedUrl = urlCodec.decode(encodedUrl);
		System.out.println("URL DECODE: " + decodedUrl);
		
		byte[] md5 = DigestUtils.md5(chunk);
		System.out.println("MD5: " + new String(md5));
		String md5Hex = DigestUtils.md5Hex(chunk);
		System.out.println("MD5 HEX: " + md5Hex);
		byte[] sha = DigestUtils.sha(chunk);
		System.out.println("SHA: " + new String(sha));
		byte[] sha512 = DigestUtils.sha512(chunk);
		System.out.println("SHA512: " + new String(sha512));
		
		byte[] asciiBytes = BinaryCodec.toAsciiBytes(chunk.getBytes());
		System.out.println("ASCII BYTES: " + new String(asciiBytes));
		byte[] fromAscii = BinaryCodec.fromAscii(asciiBytes);
		System.out.println("FROM ASCII BYTES: " + new String(fromAscii));
	}

}
