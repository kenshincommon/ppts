package test.collections;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.Bag;
import org.apache.commons.collections.Buffer;
import org.apache.commons.collections.Closure;
import org.apache.commons.collections.bag.HashBag;
import org.apache.commons.collections.buffer.CircularFifoBuffer;
import org.apache.commons.collections.functors.ClosureTransformer;
import org.apache.commons.collections.map.FixedSizeMap;
import org.apache.commons.collections.map.TransformedMap;

@SuppressWarnings("unchecked")
public class TestCollection1 {

	public static void main(String[] args) {
		Bag bag = new HashBag();
		bag.add(1);bag.add(2);bag.add(2);bag.add(3);bag.add(3);
		System.out.println("Test1: " + bag);//1:1,2:2,2:3
		System.out.println("Test2: " + bag.uniqueSet());//1,2,3
		bag.remove(2, 1);
		System.out.println("Test3: " + bag);//1:1,1:2,2:3
		
		Buffer buffer = new CircularFifoBuffer(5);
		buffer.add(new Long(4));buffer.add(new Long(1));buffer.add(new Long(18));
		buffer.add(new Long(9));buffer.add(new Long(20));buffer.add(new Long(12));
		System.out.println(buffer);
		
		Map myMap = new HashMap();
		myMap.put("one", "1");myMap.put("two", "2");myMap.put("three", "3");
		myMap = FixedSizeMap.decorate(myMap);
		try {
			myMap.put("four", "4");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		Closure echoClosure = new Closure() {
			public void execute(Object obj) {
				System.out.print(obj.toString());
			}
		};
		Closure sizeClosure = new Closure() {
			public void execute(Object obj) {
				System.out.println(" " + obj.toString().length());
			}
		};
		Map map = new HashMap();
		map = TransformedMap.decorate(map, 
				ClosureTransformer.getInstance(echoClosure), 
				ClosureTransformer.getInstance(sizeClosure));
		map.put("Hello", "World");map.put("Apache", "Commons");
		map.put("Sun", "Glassfish");
	}

}
