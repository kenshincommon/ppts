package test.collections;

import java.util.ListIterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.TreeBidiMap;
import org.apache.commons.collections.iterators.CollatingIterator;
import org.apache.commons.collections.list.CursorableLinkedList;
import org.apache.commons.collections.map.LRUMap;

@SuppressWarnings("unchecked")
public class TestCollection2 {

	public static void main(String[] args) {
		SortedMap<String,String> myMap = new TreeMap<String,String>();
		myMap.put("Hello", "World");
		myMap.put("Apple", "Orange");
		myMap.put("One", "Example of a String");
		SortedSet<String> mySet = new TreeSet<String>();
		mySet.add("Example");mySet.add("Bingo");
		CollatingIterator myIterator = new CollatingIterator();
		myIterator.setComparator(java.text.Collator.getInstance());
		myIterator.addIterator(myMap.keySet().iterator());
		myIterator.addIterator(mySet.iterator());
		while (myIterator.hasNext()) {
			System.out.println(myIterator.next());
		}
		
		CursorableLinkedList myList = new CursorableLinkedList();
		myList.add("1 (original)");
		myList.add("2 (original)");
		myList.add("3 (original)");
		ListIterator iter = myList.listIterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());
			int nextIndexValue = iter.nextIndex();
			if (nextIndexValue < 3)
				myList.add((myList.size() + 1) + " (added)");
		}

		BidiMap map = new TreeBidiMap();
		map.put("1", "one");map.put("2", "two");map.put("3", "three");
		System.out.println(map.inverseBidiMap());
		
		Map<String,String> myLRUMap = new LRUMap(3);
		myLRUMap.put("One", "1");myLRUMap.put("Two", "2");myLRUMap.put("Three", "3");
		myLRUMap.get("One");myLRUMap.get("Three");myLRUMap.put("Four", "4");
		System.out.println(myLRUMap.keySet());
	}

}
