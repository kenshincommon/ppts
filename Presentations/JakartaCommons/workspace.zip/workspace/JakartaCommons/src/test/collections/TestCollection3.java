package test.collections;

import java.util.Map;

import org.apache.commons.collections.map.LRUMap;

@SuppressWarnings("unchecked")
public class TestCollection3 {

	public static void main(String[] args) {
		Map<String,String> myLRUMap = new LRUMap(3);
		myLRUMap.put("One", "1");myLRUMap.put("Two", "2");myLRUMap.put("Three", "3");
		myLRUMap.get("One");myLRUMap.get("Three");myLRUMap.put("Four", "4");
		System.out.println(myLRUMap.keySet());
		
	}

}
