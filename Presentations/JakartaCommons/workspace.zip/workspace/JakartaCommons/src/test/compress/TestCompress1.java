package test.compress;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.compress.compressors.CompressorInputStream;
import org.apache.commons.compress.compressors.CompressorOutputStream;
import org.apache.commons.compress.compressors.CompressorStreamFactory;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.utils.IOUtils;



public class TestCompress1 {

	public static void main(String[] args) throws Exception {
		String inputFile = "test.dat";
		String compressFile = "test.gz";
		final OutputStream out = new FileOutputStream(compressFile); 
		CompressorOutputStream cos = 
			new CompressorStreamFactory().createCompressorOutputStream("gz", out);
		IOUtils.copy(new FileInputStream(inputFile), cos);
		cos.close();

		final InputStream is = new FileInputStream(compressFile); 
		CompressorInputStream in = 
			new CompressorStreamFactory().createCompressorInputStream("gz", is);
		IOUtils.copy(in, new FileOutputStream("test2.dat"));
		in.close();
		
		FileInputStream inn = new FileInputStream("test.gz");
		FileOutputStream outt = new FileOutputStream("test.tar");
		GzipCompressorInputStream bzIn = new GzipCompressorInputStream(inn);
		IOUtils.copy(bzIn, outt);
		/*final byte[] buffer = new byte[256];
		int n = 0;
		while (-1 != (n = bzIn.read(buffer))) {
		    outt.write(buffer, 0, n);
		}
		*/
		outt.close();
		bzIn.close();
		
	}

}
