package test.configuration;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationFactory;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.SystemConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;

public class TestConfiguration1 {

	public static void main(String[] args) throws Exception {
		CompositeConfiguration config = new CompositeConfiguration();
		config.addConfiguration(new SystemConfiguration());
		config.addConfiguration(new PropertiesConfiguration("application.properties"));
		System.out.println("Key1: " + config.getString("str1"));
		
		ConfigurationFactory factory = new ConfigurationFactory("config.xml");
		Configuration configuration = factory.getConfiguration();
		System.out.println("Key2:" + configuration.getString("str1"));
		
		PropertiesConfiguration configReload = new PropertiesConfiguration("application.properties");
		configReload.setReloadingStrategy(new FileChangedReloadingStrategy());
		while(true) {
			Thread.sleep(5000);
			System.out.println("Key is now: " + configReload.getString("str1"));
		}
	}

}
