package test.configuration;

import org.apache.commons.configuration.XMLConfiguration;

public class TestConfiguration2 {

	public static void main(String[] args) throws Exception {
		XMLConfiguration config = new XMLConfiguration("data.xml");
		System.out.println("BACKGROUND: " + config.getString("colors.background"));
		System.out.println("NORMAL LINK: " + config.getString("colors.link[@normal]"));
		System.out.println("DEFAULT: " + config.getString("colors.default"));
		System.out.println("ROWS: " + config.getInt("rows"));
		System.out.println("BUTTONS: " + config.getList("buttons.name"));
		System.out.println("PATTERN: " + config.getList("numberFormat[@pattern]"));
	
	}

}
