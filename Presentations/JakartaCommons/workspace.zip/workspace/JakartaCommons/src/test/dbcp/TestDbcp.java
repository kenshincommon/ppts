package test.dbcp;

import java.sql.Connection;

import org.apache.commons.dbcp.cpdsadapter.DriverAdapterCPDS;
import org.apache.commons.dbcp.datasources.SharedPoolDataSource;

public class TestDbcp {

	public static void main(String[] args) throws Exception {
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "";
		String jdbcUrl = "jdbc:mysql://localhost:3306/seam";
		DriverAdapterCPDS myConPoolDatasource = new DriverAdapterCPDS();
		myConPoolDatasource.setDriver(driver);
		myConPoolDatasource.setUrl(jdbcUrl);
		myConPoolDatasource.setUser(username);
		myConPoolDatasource.setPassword(password);
		
		SharedPoolDataSource sharedPoolDataSource = new SharedPoolDataSource();
		sharedPoolDataSource.setConnectionPoolDataSource(myConPoolDatasource);
		
		sharedPoolDataSource.setMaxActive(10);
		sharedPoolDataSource.setMaxWait(50);
		
		Connection connection1 = sharedPoolDataSource.getConnection();
		Connection connection2 = sharedPoolDataSource.getConnection();
		Connection connection3 = sharedPoolDataSource.getConnection();
		System.out.println("NUM ACTIVE: " + sharedPoolDataSource.getNumActive());//3
		connection1.close();
		connection2.close();
		connection3.close();
	}

}
