package test.dbcp;

import java.sql.Connection;

import org.apache.commons.dbcp.BasicDataSource;

public class TestDbcp2 {

	public static void main(String[] args) throws Exception {
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "";
		String jdbcUrl = "jdbc:mysql://localhost:3306/seam";
		
		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName(driver);
		ds.setUrl(jdbcUrl);
		ds.setUsername(username);
		ds.setPassword(password);
		ds.setMaxActive(10);
		ds.setMaxIdle(20);
		
		Connection conn1 = ds.getConnection();
		Connection conn2 = ds.getConnection();
		Connection conn3 = ds.getConnection();
		
		conn1.close();
		conn2.close();
		conn3.close();
	}

}
