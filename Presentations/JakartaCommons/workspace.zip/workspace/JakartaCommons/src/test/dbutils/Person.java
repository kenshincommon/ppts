package test.dbutils;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Person {

	private Long id = null;
	private String nume = null;
	private String prenume = null;
	
	public Person(){}
	
	public Person(String nume, String prenume){
		setNume(nume);
		setPrenume(prenume);
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getPrenume() {
		return prenume;
	}
	public void setPrenume(String prenume) {
		this.prenume = prenume;
	}
	public String toString(){
		return ToStringBuilder.reflectionToString(this);
	}
	
}
