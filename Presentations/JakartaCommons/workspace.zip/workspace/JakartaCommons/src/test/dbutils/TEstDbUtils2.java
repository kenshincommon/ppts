package test.dbutils;

import java.util.List;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.apache.commons.lang.ArrayUtils;

public class TEstDbUtils2 {

	public static void main(String[] args) throws Exception {
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "";
		String jdbcUrl = "jdbc:mysql://localhost:3306/jpa2";
		
		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName(driver);
		ds.setUrl(jdbcUrl);
		ds.setUsername(username);
		ds.setPassword(password);
		ds.setMaxActive(10);
		ds.setMaxIdle(20);
		
		ResultSetHandler<List<Person>> handler = new BeanListHandler<Person>(Person.class);
		QueryRunner run = new QueryRunner(ds);
		List<Person> persons = run.query("SELECT * FROM Person", handler);
		System.out.println("Persons: " + persons);
		
		ScalarHandler scalarHandler1 = new ScalarHandler("prenume");
		ScalarHandler scalarHandler2 = new ScalarHandler(2);
		System.out.println("Q1: " + run.query("SELECT * FROM Person", scalarHandler1));
		System.out.println("Q2: " + run.query("SELECT * FROM Person", scalarHandler2));
		
		MapHandler mapHandler = new MapHandler();
		System.out.println("MAP HANDLER: " + run.query("SELECT * FROM Person", mapHandler));
		
		ArrayHandler arrayHandler = new ArrayHandler();
		System.out.println("ARRAY HANDLER: " + 
				ArrayUtils.toString(run.query("SELECT * FROM Person", arrayHandler)));
	}

}
