package test.dbutils;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

public class TestDbUtils1 {

	public static void main(String[] args) throws Exception {
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "";
		String jdbcUrl = "jdbc:mysql://localhost:3306/jpa";
		
		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName(driver);
		ds.setUrl(jdbcUrl);
		ds.setUsername(username);
		ds.setPassword(password);
		ds.setMaxActive(10);
		ds.setMaxIdle(20);
		
		ResultSetHandler<Object[]> handler = new ResultSetHandler<Object[]>() {
			
			@Override
			public Object[] handle(ResultSet rs) throws SQLException {
				ResultSetMetaData metaData = rs.getMetaData();
				int columnCount = metaData.getColumnCount();
				Object[] result = new Object[columnCount];
				while(rs.next()) {
					for(int i=0;i<columnCount;i++) {
						result[i] = rs.getObject(i+1);
					}
				}
				return result;
			}
		};
		
		QueryRunner runner = new QueryRunner(ds);
		String sqlQuery = "SELECT * from Orders where id=?";
		Object[] objects = runner.query(sqlQuery, handler, 1);
		System.out.println(Arrays.asList(objects));
	}

}
