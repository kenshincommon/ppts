package test.digester;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Student {
	private String name;
	private String address;

	public Student() {}

	public String getName() {
		return name;
	}
	public void setName(String newName) {
		name = newName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
