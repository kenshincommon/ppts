package test.digester;

import java.io.FileInputStream;
import java.util.List;
import java.util.Vector;

import org.apache.commons.digester.Digester;

public class TestDigesterStudents {

	private List<Student> students = new Vector<Student>();
	
	public void digest() throws Exception {
		Digester digester = new Digester();
		digester.push(this);
		
		digester.addObjectCreate("students/student", Student.class);
		digester.addBeanPropertySetter("students/student/name");
		digester.addBeanPropertySetter("students/student/address","address");
		
		digester.addSetNext("students/student", "adaugaUrmatorul");
		
		digester.parse(new FileInputStream("students.xml"));
		System.out.println("STUDENTS: " + students);
	}
	
	public void adaugaUrmatorul(Student student) {
		System.out.println("Adaugam: " + student);
		students.add(student);
	}

	public static void main(String args[]) throws Exception {
		TestDigesterStudents test = new TestDigesterStudents();
		test.digest();
	}
	
}
