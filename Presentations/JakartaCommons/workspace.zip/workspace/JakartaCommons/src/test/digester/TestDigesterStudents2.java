package test.digester;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import org.apache.commons.digester.Digester;
import org.apache.commons.digester.xmlrules.DigesterLoader;

@SuppressWarnings("all")
public class TestDigesterStudents2 {

	private List<Student> students = new Vector<Student>();
	
	public void digest() throws Exception {
		URL rules = new File("rules.xml").toURL();
		System.out.println("URL RULES: " + rules);
		Digester digester = DigesterLoader.createDigester(rules);
		digester.push(this);
		
		digester.parse(new FileInputStream("students.xml"));
		System.out.println("STUDENTS: " + students);
	}
	
	public void adaugaUrmatorul(Student student) {
		System.out.println("Adaugam: " + student);
		students.add(student);
	}

	public static void main(String args[]) throws Exception {
		TestDigesterStudents2 test = new TestDigesterStudents2();
		test.digest();
	}
	
}
