package test.exec;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteWatchdog;


public class TestExec1 {

	public static void main(String[] args) throws Exception {
		File pdfFile = new File("c:\\IT0003919989.pdf");
		
		//String line = "AcroRd32.exe /p /h " + pdfFile.getAbsolutePath();
		//CommandLine commandLine = CommandLine.parse(line);
		
		CommandLine commandLine = CommandLine.parse("AcroRd32.exe");
		commandLine.addArgument("/p");
		commandLine.addArgument("/h");
		commandLine.addArgument(pdfFile.getAbsolutePath());
		
		CommandLine commandLine2 = CommandLine.parse("AcroRd32.exe");
		commandLine2.addArgument("/p");
		commandLine2.addArgument("/h");
		commandLine2.addArgument("${file}");
		Map<String,String> map = new HashMap<String,String>();
		map.put("file", "C:\\432432.pdf");
		commandLine2.setSubstitutionMap(map);
		
		DefaultExecutor executor = new DefaultExecutor();
		ExecuteWatchdog watchdog = new ExecuteWatchdog(60000);
		executor.setWatchdog(watchdog);
		int exitValue = executor.execute(commandLine);
		System.out.println("Exit value: " + exitValue);
	}

}
