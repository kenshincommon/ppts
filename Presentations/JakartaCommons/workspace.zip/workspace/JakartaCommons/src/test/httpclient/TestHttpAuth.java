package test.httpclient;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;

public class TestHttpAuth {

	public static void main(String[] args) throws Exception {
		String userName = "ionut";
		String password = "ionut";
		Credentials credentials = new UsernamePasswordCredentials(userName,password);
		HttpClient httpClient = new HttpClient();
		httpClient.getParams().setAuthenticationPreemptive(true);
		httpClient.getState().setCredentials(new AuthScope("localhost", 8080, AuthScope.ANY_REALM), credentials);
		HttpMethod method = new GetMethod("http://localhost:8080/Web3");
		httpClient.executeMethod(method);
		System.out.println("STATUS CODE: " + method.getStatusCode());
		System.out.println(method.getResponseBodyAsString());
		method.releaseConnection();
	}

}
