package test.httpclient;

import java.util.Arrays;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;

public class TestHttpGet {

	public static void main(String[] args)throws Exception {
		//HttpClient httpClient = new HttpClient(new MultiThreadedHttpConnectionManager());
		HttpClient httpClient = new HttpClient();
		HttpMethod httpMethod = new GetMethod("http://www.google.ro");
		httpClient.executeMethod(httpMethod);
		System.out.println(httpMethod.getStatusCode());
		System.out.println(httpMethod.getResponseBodyAsString());
		System.out.println("FALLOW REDIRECT: " + httpMethod.getFollowRedirects());
		System.out.println("PATH: " + httpMethod.getPath());
		System.out.println("Cookies: " + Arrays.asList(httpClient.getState().getCookies()));
		
		httpMethod.releaseConnection();
		
	}

}
