package test.httpclient;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.PostMethod;

public class TestHttpPost {

	public static void main(String[] args) throws Exception {
		String userName = "ionut";
		String password = "ionut";
		Credentials credentials = new UsernamePasswordCredentials(userName,password);
		HttpClient httpClient = new HttpClient();
		httpClient.getState().setCredentials(new AuthScope("localhost", 8080, AuthScope.ANY_REALM), credentials);
		
		PostMethod post = new PostMethod("http://localhost:8080/Web3/post1");
		NameValuePair[] data = {
		          new NameValuePair("username", "ruroni"),
		          new NameValuePair("password", "kenshin")
		};
		post.setRequestBody(data);
		
		httpClient.executeMethod(post);
		
		//InputStream is = post.getResponseBodyAsStream();
		String responseBodyAsString = post.getResponseBodyAsString();
		System.out.println("RESPONSE: " + responseBodyAsString);

		post.releaseConnection();
	}

}
