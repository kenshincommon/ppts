package test.httpclient;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;

public class TestHttpProxy {

	public static void main(String args[]) throws Exception {
		HttpClient httpclient = new HttpClient();
		httpclient.getHostConfiguration().setProxy("myproxyhost", 8080);
		httpclient.getState().setProxyCredentials(new AuthScope("myproxyhost", 8080), 
				new UsernamePasswordCredentials("my-proxy-username","my-proxy-password"));
		GetMethod httpget = new GetMethod("https://www.verisign.com/");
		try {
			httpclient.executeMethod(httpget);
			System.out.println(httpget.getStatusLine());
		} finally {
			httpget.releaseConnection();
		}
	}

}
