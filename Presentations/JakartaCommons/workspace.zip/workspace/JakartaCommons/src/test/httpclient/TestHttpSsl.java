package test.httpclient;


public class TestHttpSsl {

	public static void main(String[] args) {
		
		
	}

}
