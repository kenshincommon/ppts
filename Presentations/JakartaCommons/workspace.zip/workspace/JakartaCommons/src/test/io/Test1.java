package test.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

@SuppressWarnings("unchecked")
public class Test1 {

	public static void main(String[] args) throws Exception {
		Writer writer = null;
		InputStream inputStream = null;
		try {
			writer = new FileWriter("test.dat");
			inputStream = new FileInputStream("test.txt");
			//System.out.println("LENGTH: " + IOUtils.toByteArray(inputStream).length);
			//System.out.println("CONTENT: [" + IOUtils.toString(inputStream) + "] ");
			IOUtils.copy(inputStream, writer);
			System.out.println("Copy done");
		} catch (IOException e) {
			System.out.println("Error copying data");
		} finally {
			IOUtils.closeQuietly(writer);
			IOUtils.closeQuietly(inputStream);
		}
		
		File file = new File("test.txt");
		List<String> fileLines = FileUtils.readLines(file);
		System.out.println("-----START-----");
		for(String line : fileLines) { 
			System.out.println(line);
		}
		System.out.println("-----END-----");
		System.out.println("LENGTH: " + FileUtils.readFileToByteArray(file).length);
		System.out.println("LENGTH: " + file.length());
	}

}
