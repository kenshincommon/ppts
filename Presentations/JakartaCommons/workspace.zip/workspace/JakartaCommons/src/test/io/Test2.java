package test.io;

import java.io.File;
import java.io.FilenameFilter;

import org.apache.commons.io.FileSystemUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.lang.ArrayUtils;

public class Test2 {

	public static void main(String[] args) throws Exception {
		System.out.println("Free space: " + FileSystemUtils.freeSpaceKb("c:"));
		LineIterator it = FileUtils.lineIterator(new File("test.txt"), "UTF-8");
		try {
			System.out.println("----------");
			while (it.hasNext()) {
				System.out.println(it.nextLine());
			}
			System.out.println("----------");
		} finally {
			LineIterator.closeQuietly(it);
		}
		
		File newFile = new File("new");
		FileUtils.touch(newFile);
		FileUtils.deleteQuietly(newFile);
		
		File rootDir = new File(".");
		FilenameFilter fileFilter = new SuffixFileFilter(".txt");
		System.out.println(ArrayUtils.toString(rootDir.list(fileFilter)));
		
	}

}
