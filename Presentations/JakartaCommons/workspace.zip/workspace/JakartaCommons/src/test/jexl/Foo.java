package test.jexl;

public class Foo {

	public String bar(){
		return "Called from bar";
	}

}
