package test.jexl;

import org.apache.commons.jexl.Expression;
import org.apache.commons.jexl.ExpressionFactory;
import org.apache.commons.jexl.JexlContext;
import org.apache.commons.jexl.JexlHelper;

@SuppressWarnings("unchecked")
public class TestJexl1 {

	public static void main(String[] args) throws Exception {
	    // Create an expression object
		String jexlExp = "foo.bar()";
	    Expression e = ExpressionFactory.createExpression( jexlExp );

	    // Create a context and add data
	    JexlContext jc = JexlHelper.createContext();
	    jc.getVars().put("foo", new Foo() );

	    // Now evaluate the expression, getting the result
	    Object o = e.evaluate(jc);
	    System.out.println(o);
	}

}
