package test.lang;

import java.util.ArrayList;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.CharSet;
import org.apache.commons.lang.CharSetUtils;
import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.RandomStringUtils;

public class TestLang1 {

	public static void main(String[] args) {
		int[] tab1 = {1,2,3,5,6,7,8};
		System.out.println("Test1: " + ArrayUtils.contains(tab1, 4));//false
		System.out.println("Test2: " + ArrayUtils.indexOf(tab1, 2));//1
		System.out.println("Test3: " + ArrayUtils.toString(ArrayUtils.add(tab1, 10)));
		
		boolean testBool = false;
		System.out.println("Test4: " + BooleanUtils.toString(testBool, "ready", "not ready"));
		System.out.println("Test5: " + BooleanUtils.toStringOnOff(testBool));
		System.out.println("Test6: " + BooleanUtils.toStringTrueFalse(testBool));
		
		String str1 = "abc123def456";
		String str2 = "aaaabbbbcddddeee";
		System.out.println("Test7: " + 
				CharSetUtils.delete(str1, CharSet.ASCII_NUMERIC.toString()));//abcdef
		System.out.println("Test8: " + 
				CharSetUtils.keep(str1, CharSet.ASCII_NUMERIC.toString()));//123456
		System.out.println("Test9: " + 
				CharSetUtils.squeeze(str2, CharSet.ASCII_ALPHA.toString()));//abcde
		
		System.out.println("Test10: " + ClassUtils.getAllSuperclasses(ArrayList.class));
		
		System.out.println("Test11: " + RandomStringUtils.random(8,new char[]{'A', 'B', 'C'}));
		System.out.println("Test12: " + RandomStringUtils.randomAscii(16));
		System.out.println("Test13: " + RandomStringUtils.randomNumeric(12));
		System.out.println("Test14: " + RandomStringUtils.randomAlphanumeric(20));
		System.out.println("Test15: " + RandomStringUtils.random(10, true, true));
	}

}
