package test.lang;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;

public class TestLang2 {

	public static void main(String[] args) throws Exception {
		String fName = "test.dat";
		String content = "I'm going to be serialized :)";
		byte[] contentByte = SerializationUtils.serialize(content);
		System.out.println(SerializationUtils.deserialize(contentByte));
		
		FileOutputStream fos = new FileOutputStream(fName);
		SerializationUtils.serialize(content, fos);
		fos.close();

		FileInputStream fis = new FileInputStream(fName);
		System.out.println(SerializationUtils.deserialize(fis));
		fis.close();
		
		String htmlChunk = "<B>$ to \u00A3 Right</B>";
		String SQL = "Ain't bad";
		String Java = "\"It's on my \t tab\"";
		System.out.println(StringEscapeUtils.escapeHtml(htmlChunk));
		System.out.println(StringEscapeUtils.escapeXml(htmlChunk));
		System.out.println(StringEscapeUtils.escapeSql(SQL));
		System.out.println(StringEscapeUtils.escapeJava(Java));
		System.out.println(StringEscapeUtils.escapeJavaScript(Java));
		
		String longText = "This is a very long line of text";
		System.out.println(StringUtils.abbreviate(longText, 15));//This is a ve...
		System.out.println(StringUtils.getLevenshteinDistance("time", "trimed"));
		
		String str = "java is the BEST ever!";
		System.out.println(WordUtils.capitalize(str));
		System.out.println(WordUtils.capitalizeFully(str));
		System.out.println(WordUtils.swapCase(str));
		System.out.println(WordUtils.wrap(str,8));
	}

}
