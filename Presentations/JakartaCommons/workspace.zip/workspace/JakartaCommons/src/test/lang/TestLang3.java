package test.lang;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.math.Fraction;
import org.apache.commons.lang.time.StopWatch;

@SuppressWarnings("unused")
public class TestLang3 {

	public static void main(String[] args) throws Exception {
		Object obj = new Object(){
			private String[] tab = {"elem1","elem2","elem3","elem4"};
			private int elemInt = 25;
			public String toString(){
				//return ReflectionToStringBuilder.toString(this);
				return ToStringBuilder.reflectionToString(this);
			}
			public int hashCode(){
				return HashCodeBuilder.reflectionHashCode(this);
			}
			public boolean equals(Object obj) {
				return EqualsBuilder.reflectionEquals(this, obj);
			}
		};
		System.out.println("TO_STRING: " + obj);
		System.out.println("HASH_CODE: " + obj.hashCode());
		System.out.println("EQUALS: " + obj.equals(obj));
		
		Fraction fraction1 = Fraction.getFraction(5, 10);
		Fraction fraction2 = fraction1.add(Fraction.getFraction(2, 5));
		System.out.println("NUMERATOR: " + fraction2.getNumerator());//10
		System.out.println("DENOMINATOR: " + fraction2.getDenominator());//9
		
		StopWatch watch = new StopWatch();
		watch.start();
		Thread.sleep(2000);
		watch.stop();
		System.out.println("WATCH TIME: " + watch.getTime());
	}

}
