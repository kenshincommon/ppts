package test.logging;

import java.util.logging.Level;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Jdk14Logger;

public class TestLogging1 {

	public static void main(String[] args) throws Exception {
		Log logger = LogFactory.getLog(TestLogging1.class);
		if(logger instanceof Jdk14Logger) {
			((Jdk14Logger)logger).getLogger().setLevel(Level.ALL);
			((Jdk14Logger)logger).getLogger().addHandler((java.util.logging.FileHandler)Class
					.forName("java.util.logging.FileHandler")
					.newInstance());
			System.out.println("Logger configured");
		}
		logger.info("Logger: " + logger);
		logger.trace("trace");
		logger.fatal("fatal");
		logger.info("info");
		logger.warn("warn");
	}

}
