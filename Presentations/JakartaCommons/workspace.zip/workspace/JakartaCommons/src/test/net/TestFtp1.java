package test.net;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

public class TestFtp1 {

	public static void main(String[] args) throws Exception {
		String hostName = "172.20.35.178";
		String userName = "dev";
		String password = "dev";
		FTPClient ftpClient = new FTPClient();
		ftpClient.connect(hostName);
		ftpClient.login(userName, password);
		System.out.println("Reply Code: " + ftpClient.getReplyCode());//IF OK -->230
		System.out.println("Working directory: " + ftpClient.printWorkingDirectory());
		System.out.println("Local Port: " + ftpClient.getLocalPort());
		FTPFile[] listFiles = ftpClient.listFiles();
		for(FTPFile file : listFiles) {
			System.out.println("-> " + file.getName());
		}
		ftpClient.changeWorkingDirectory("..");
		ftpClient.changeToParentDirectory();
		ftpClient.disconnect();
	}

}
