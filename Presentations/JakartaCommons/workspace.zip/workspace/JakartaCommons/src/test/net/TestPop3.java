package test.net;

import java.io.BufferedReader;
import java.io.Reader;

import org.apache.commons.net.pop3.POP3Client;
import org.apache.commons.net.pop3.POP3MessageInfo;

public class TestPop3 {

	public static void main(String[] args) throws Exception {
		String hostname = "localhost";
		String username = "kenshin";
		String password = "kenshin";
		POP3Client pop3Client = new POP3Client();
		pop3Client.connect(hostname);
		pop3Client.login(username, password);
		System.out.println("State: " + pop3Client.getState());//1
		System.out.println("Reply String: " + pop3Client.getReplyString());
		System.out.println("Connected: " + pop3Client.isConnected());//true
		POP3MessageInfo[] listMessages = pop3Client.listMessages();
		System.out.println("START READING MESSAGES");
		for(POP3MessageInfo msgInfo : listMessages) {
			Reader retrieveMessage = pop3Client.retrieveMessage(msgInfo.number);
			BufferedReader bufferedReader = new BufferedReader(retrieveMessage);
			System.out.println(">>>>>>>>>>>>>>>>>>");
			String line = bufferedReader.readLine();
			while(line != null) {
				System.out.println(line);
				line = bufferedReader.readLine();
			}
			bufferedReader.close();
			System.out.println(">>>>>>>>>>>>>>>>>>");
		}
		System.out.println("END READING MESSAGES");
		pop3Client.logout();
		pop3Client.disconnect();
	}

}
