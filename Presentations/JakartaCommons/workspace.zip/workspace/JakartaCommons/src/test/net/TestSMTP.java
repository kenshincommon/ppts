package test.net;

import org.apache.commons.net.smtp.SMTPClient;

@SuppressWarnings("unused")
public class TestSMTP {

	public static void main(String[] args) throws Exception {
		String hostname = "localhost";
		String username = "kenshin";
		String password = "kenshin";
		SMTPClient smtpClient = new SMTPClient();
		smtpClient.connect(hostname);
		smtpClient.login();
		System.out.println("Reply String: " + smtpClient.getReplyString());
		boolean state = smtpClient.sendSimpleMessage("hehe@localhost", 
				"kenshin@localhost", "Mesaj de citit");
		System.out.println("State is: " + state);
		
		smtpClient.logout();
		smtpClient.disconnect();
		
	}

}
