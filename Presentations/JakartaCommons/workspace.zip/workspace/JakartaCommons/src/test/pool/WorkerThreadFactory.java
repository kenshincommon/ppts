package test.pool;

import org.apache.commons.pool.PoolableObjectFactory;

public class WorkerThreadFactory implements PoolableObjectFactory {

	/** Keeps track of the currently created thread. */
	public int currentThread = 0;
	
	public Object makeObject() throws Exception {
		Thread temp = new WorkerThread();
		temp.setName("Worker Thread #" + currentThread++);
		return temp;
	}
	
	public void activateObject(Object obj) throws Exception {}

	public void destroyObject(Object obj) throws Exception {}

	public void passivateObject(Object obj) throws Exception {
	}

	public boolean validateObject(Object obj) {
		return false;
	}

}
