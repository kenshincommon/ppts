package test.scxml;

import java.io.File;
import java.net.URL;

import org.apache.commons.scxml.Evaluator;
import org.apache.commons.scxml.env.jsp.ELEvaluator;
import org.apache.commons.scxml.io.SCXMLParser;
import org.apache.commons.scxml.model.SCXML;
import org.apache.commons.scxml.test.StandaloneUtils;
import org.xml.sax.helpers.DefaultHandler;

@SuppressWarnings("deprecation")
public class Test1 {

	public static void main(String[] args) throws Exception {
		
		URL urlFile = new File("test1.xml").toURL();
		System.out.println("URL FILE: " + urlFile);
		SCXML scxml = SCXMLParser.parse(urlFile, new DefaultHandler());
		System.out.println("Initial State: [" +  scxml.getInitial() + "]");
		
		Evaluator evaluator = new ELEvaluator();
		StandaloneUtils.execute("test1.xml", evaluator);
	}

}
