package com.kenshin;

import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class TestIndexer {

	private static String DATA_DIR = "data";

	private static String INDEX_DIR = "idx_data";

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		
		FileFilter filter = new FileFilter() {
			public boolean accept(File path) {
				return path.getName().toLowerCase().endsWith(".txt");
			}
		};
		
		Directory dir = null;
		IndexWriter writer = null;
		int numIndexed = 0;
		try {
			dir = FSDirectory.open(new File(INDEX_DIR));
			IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_30,
					new StandardAnalyzer(Version.LUCENE_30));
			writer = new IndexWriter(dir, config);

			File[] files = new File(DATA_DIR).listFiles();
			for (File f : files) {
				if (!f.isDirectory() && !f.isHidden() && f.exists()
						&& f.canRead() && (filter == null || filter.accept(f))) {
					indexFile(writer, f);
				}
			}
			numIndexed = writer.numDocs();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			long end = System.currentTimeMillis();
			System.out.println("Indexing " + numIndexed + " files took "
					+ (end - start) + " milliseconds");
			if (writer != null) {
				try {
					writer.close();
				} catch (CorruptIndexException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			try {
				dir.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	protected static Document getDocument(File f) throws IOException  {
		Document doc = new Document();
		doc.add(new Field("contents", new FileReader(f)));
		doc.add(new Field("filename", f.getName(), Field.Store.YES,Field.Index.NOT_ANALYZED));
		doc.add(new Field("fullpath", f.getCanonicalPath(), Field.Store.YES,Field.Index.NOT_ANALYZED));
		return doc;
	}
	
	private static void indexFile(IndexWriter writer, File f) throws IOException {
		System.out.println("Indexing " + f.getCanonicalPath());
		Document doc = getDocument(f);
		writer.addDocument(doc);
	}

}
