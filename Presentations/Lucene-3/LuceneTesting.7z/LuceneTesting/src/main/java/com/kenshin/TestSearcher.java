package com.kenshin;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class TestSearcher {

	private static String INDEX_DIR = "idx_data";
	
	public static void main(String[] args) {
		Directory dir = null;
		IndexSearcher is = null;
		IndexReader idxReader = null;
		String queryStr = "dummy";
//		String queryStr = "1.7.0_15";
		long start = System.currentTimeMillis();
		try {
			dir = FSDirectory.open(new File(INDEX_DIR));
			QueryParser parser = new QueryParser(Version.LUCENE_30,
					"contents",new StandardAnalyzer(Version.LUCENE_30));
			
			idxReader = IndexReader.open(dir);
			is = new IndexSearcher(idxReader);
			
			Query query = parser.parse(queryStr);
			TopDocs hits = is.search(query, 10);
			long end = System.currentTimeMillis();
			System.out.println("Found " + hits.totalHits + " document(s) (in "
					+ (end - start) + " milliseconds) that matched query '"
					+ queryStr + "':");
			
			for(ScoreDoc scoreDoc : hits.scoreDocs) {
				Document doc = is.doc(scoreDoc.doc);
				System.out.println(doc.get("fullpath"));
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			try {
				idxReader.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			try {
				is.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				dir.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}
