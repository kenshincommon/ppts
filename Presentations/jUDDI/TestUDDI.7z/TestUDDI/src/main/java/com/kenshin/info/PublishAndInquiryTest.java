package com.kenshin.info;

import java.rmi.RemoteException;

import org.apache.juddi.v3.client.transport.JAXWSTransport;
import org.apache.juddi.v3.client.transport.TransportException;
import org.uddi.api_v3.AuthToken;
import org.uddi.api_v3.BusinessDetail;
import org.uddi.api_v3.BusinessEntity;
import org.uddi.api_v3.Description;
import org.uddi.api_v3.GetAuthToken;
import org.uddi.api_v3.GetBusinessDetail;
import org.uddi.api_v3.Name;
import org.uddi.api_v3.SaveBusiness;
import org.uddi.v3_service.DispositionReportFaultMessage;
import org.uddi.v3_service.UDDIInquiryPortType;
import org.uddi.v3_service.UDDIPublicationPortType;
import org.uddi.v3_service.UDDISecurityPortType;

public class PublishAndInquiryTest {

	
	
	public static void main(String[] args) throws Exception {
		String user = "root";
		String pass = "password";
		String name = "Looney Tunes";
		String desc = "Desc goes here";
		
		/**
		 * AUTH PHASE
		 */
		JAXWSTransport transport = new JAXWSTransport();
		AuthToken authToken = getAuthToken(transport, user, pass);
		String authInfo = authToken.getAuthInfo();
		System.out.println("AuthInfo: " + authInfo);
		
		/**
		 * PUBLISH PHASE
		 */
		BusinessDetail busDetails = saveBusiness(transport, authToken.getAuthInfo(), name, desc);
		BusinessEntity businessEntity = busDetails.getBusinessEntity().get(0);
		printBusinessEntity(businessEntity);
		
		/**
		 * INQUIRY PHASE
		 */
		BusinessDetail business = getBusiness(transport, businessEntity.getBusinessKey());
		printBusinessEntity(business.getBusinessEntity().get(0));
	}
	
	public static void printBusinessEntity(BusinessEntity entity) {
		if(entity != null) {
			System.out.println("BusinessKey: " + entity.getBusinessKey());
			System.out.println("Names: " + entity.getName().get(0).getValue());
			System.out.println("Descriptions: " + entity.getDescription().get(0).getValue());
		}
	}
	
	public static BusinessDetail getBusiness(JAXWSTransport transport, String busKey) throws TransportException, DispositionReportFaultMessage, RemoteException {
		UDDIInquiryPortType inquiryService = transport.getUDDIInquiryService();
		GetBusinessDetail businessDetail = new GetBusinessDetail();
		businessDetail.getBusinessKey().add(busKey);
		return inquiryService.getBusinessDetail(businessDetail);
	}
	
	public static BusinessDetail saveBusiness(JAXWSTransport transport, String authInfo, String name, String desc) throws TransportException, DispositionReportFaultMessage, RemoteException{
		UDDIPublicationPortType pubService = transport.getUDDIPublishService();
		
		BusinessEntity myBusEntity = new BusinessEntity();
		Name myBusName = new Name();
		myBusName.setValue(name);
		Description description = new Description();
		description.setValue(desc);
		myBusEntity.getName().add(myBusName);
		myBusEntity.getDescription().add(description);
		
		SaveBusiness business = new SaveBusiness();
		business.getBusinessEntity().add(myBusEntity); 
		business.setAuthInfo(authInfo);
		return pubService.saveBusiness(business);
	}
	
	public static AuthToken getAuthToken(JAXWSTransport transport, String user, String pass) throws TransportException, DispositionReportFaultMessage, RemoteException {
		UDDISecurityPortType secService = transport.getUDDISecurityService();
		GetAuthToken ga = new GetAuthToken();
		ga.setUserID(user);
		ga.setCred(pass);
		return secService.getAuthToken(ga);
	}
	
}
