package com.kenshin.security;

import java.rmi.RemoteException;

import org.apache.juddi.v3.client.transport.JAXWSTransport;
import org.apache.juddi.v3.client.transport.TransportException;
import org.uddi.api_v3.AuthToken;
import org.uddi.api_v3.GetAuthToken;
import org.uddi.v3_service.DispositionReportFaultMessage;
import org.uddi.v3_service.UDDISecurityPortType;

public class TestSecurity {

	public static void main(String[] args) throws TransportException, DispositionReportFaultMessage, RemoteException {

		JAXWSTransport transport = new JAXWSTransport();
		UDDISecurityPortType secService = transport.getUDDISecurityService();
		System.out.println(secService); 
		
		GetAuthToken ga = new GetAuthToken();
		ga.setUserID("root");
		ga.setCred("test");
		AuthToken token = secService.getAuthToken(ga);
		System.out.println("AuthInfo: " + token.getAuthInfo());
	}

}
